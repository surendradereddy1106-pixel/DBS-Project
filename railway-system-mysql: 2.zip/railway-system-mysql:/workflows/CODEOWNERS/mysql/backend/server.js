const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

/* =========================================================
   MYSQL CONNECTION
   ========================================================= */

const db = mysql.createPool({
    host: "127.0.0.1",
    port: 3307,
    user: "railway_user",
    password: "railway_password",
    database: "railway_system",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

/* =========================================================
   TEST DATABASE CONNECTION
   ========================================================= */

async function testDatabase() {
    try {
        const connection = await db.getConnection();

        console.log("====================================");
        console.log("MYSQL DATABASE CONNECTED");
        console.log("Database: railway_system");
        console.log("====================================");

        connection.release();
    } catch (error) {
        console.error("MYSQL CONNECTION FAILED");
        console.error(error.message);
    }
}

testDatabase();

/* =========================================================
   HOME API
   ========================================================= */

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Railway Reservation Backend is running"
    });
});

/* =========================================================
   SEARCH TRAINS
   ========================================================= */

app.get("/api/trains", async (req, res) => {

    try {

        const { source, destination } = req.query;

        if (!source || !destination) {
            return res.status(400).json({
                success: false,
                message: "Source and destination are required"
            });
        }

        const sourceStation = source.trim();
        const destinationStation = destination.trim();

        const [trains] = await db.execute(
            `
            SELECT
                id,
                train_number,
                train_name,
                source_station,
                destination_station,
                departure_time,
                arrival_time,
                duration
            FROM trains
            WHERE LOWER(source_station) = LOWER(?)
            AND LOWER(destination_station) = LOWER(?)
            ORDER BY departure_time
            `,
            [sourceStation, destinationStation]
        );

        res.json({
            success: true,
            count: trains.length,
            trains: trains
        });

    } catch (error) {

        console.error("TRAIN SEARCH ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Unable to search trains",
            error: error.message
        });
    }
});

/* =========================================================
   GET ALL TRAINS
   ========================================================= */

app.get("/api/all-trains", async (req, res) => {

    try {

        const [trains] = await db.execute(
            `
            SELECT
                id,
                train_number,
                train_name,
                source_station,
                destination_station,
                departure_time,
                arrival_time,
                duration
            FROM trains
            ORDER BY train_name
            `
        );

        res.json({
            success: true,
            count: trains.length,
            trains: trains
        });

    } catch (error) {

        console.error("ALL TRAINS ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Unable to get trains",
            error: error.message
        });
    }
});

/* =========================================================
   CREATE BOOKINGS TABLE
   ========================================================= */

async function createBookingsTable() {

    try {

        await db.execute(`
            CREATE TABLE IF NOT EXISTS bookings (

                id INT AUTO_INCREMENT PRIMARY KEY,

                train_id INT,

                train_number VARCHAR(20),

                train_name VARCHAR(150),

                source_station VARCHAR(100),

                destination_station VARCHAR(100),

                passenger_name VARCHAR(100) NOT NULL,

                email VARCHAR(150) NOT NULL,

                phone VARCHAR(20) NOT NULL,

                age INT,

                gender VARCHAR(20),

                seat_preference VARCHAR(50),

                address TEXT,

                journey_date DATE,

                booking_status VARCHAR(30) DEFAULT 'CONFIRMED',

                booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        console.log("Bookings table ready");

    } catch (error) {

        console.error("BOOKINGS TABLE ERROR:", error.message);
    }
}

createBookingsTable();

/* =========================================================
   BOOK TICKET
   ========================================================= */

app.post("/api/bookings", async (req, res) => {

    try {

        const {
            trainId,
            trainNumber,
            trainName,
            source,
            destination,
            passengerName,
            email,
            phone,
            age,
            gender,
            seatPreference,
            address,
            journeyDate
        } = req.body;

        /* -----------------------------------------
           VALIDATION
           ----------------------------------------- */

        if (
            !passengerName ||
            !email ||
            !phone ||
            !trainNumber ||
            !trainName ||
            !source ||
            !destination
        ) {

            return res.status(400).json({
                success: false,
                message: "Please fill all required passenger details"
            });
        }

        /* -----------------------------------------
           INSERT BOOKING
           ----------------------------------------- */

        const [result] = await db.execute(
            `
            INSERT INTO bookings
            (
                train_id,
                train_number,
                train_name,
                source_station,
                destination_station,
                passenger_name,
                email,
                phone,
                age,
                gender,
                seat_preference,
                address,
                journey_date,
                booking_status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED')
            `,
            [
                trainId || null,
                trainNumber,
                trainName,
                source,
                destination,
                passengerName,
                email,
                phone,
                age || null,
                gender || null,
                seatPreference || null,
                address || null,
                journeyDate || null
            ]
        );

        /* -----------------------------------------
           SUCCESS RESPONSE
           ----------------------------------------- */

        res.status(201).json({

            success: true,

            message: "Ticket booked successfully",

            booking: {
                bookingId: result.insertId,
                trainNumber: trainNumber,
                trainName: trainName,
                passengerName: passengerName,
                source: source,
                destination: destination,
                journeyDate: journeyDate,
                status: "CONFIRMED"
            }
        });

    } catch (error) {

        console.error("BOOKING ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Unable to complete booking",
            error: error.message
        });
    }
});

/* =========================================================
   GET ALL BOOKINGS
   ========================================================= */

app.get("/api/bookings", async (req, res) => {

    try {

        const [bookings] = await db.execute(
            `
            SELECT *
            FROM bookings
            ORDER BY booking_time DESC
            `
        );

        res.json({
            success: true,
            count: bookings.length,
            bookings: bookings
        });

    } catch (error) {

        console.error("GET BOOKINGS ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Unable to get bookings",
            error: error.message
        });
    }
});

/* =========================================================
   GET SINGLE BOOKING
   ========================================================= */

app.get("/api/bookings/:id", async (req, res) => {

    try {

        const bookingId = req.params.id;

        const [bookings] = await db.execute(
            `
            SELECT *
            FROM bookings
            WHERE id = ?
            `,
            [bookingId]
        );

        if (bookings.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Booking not found"
            });
        }

        res.json({
            success: true,
            booking: bookings[0]
        });

    } catch (error) {

        console.error("BOOKING FETCH ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Unable to fetch booking",
            error: error.message
        });
    }
});

/* =========================================================
   START SERVER
   ========================================================= */

app.listen(PORT, () => {

    console.log("");
    console.log("======================================");
    console.log("RAILWAY RESERVATION BACKEND");
    console.log("======================================");
    console.log(`Server running at: http://localhost:${PORT}`);
    console.log("======================================");
    console.log("");

});