const mysql = require("mysql2/promise");

const pool = mysql.createPool({
    host: process.env.DB_HOST || "localhost",

    port: Number(process.env.DB_PORT || 3306),

    user: process.env.DB_USER || "railway_user",

    password: process.env.DB_PASSWORD || "railway_password",

    database: process.env.DB_NAME || "railway_system",

    waitForConnections: true,

    connectionLimit: Number(
        process.env.DB_CONNECTION_LIMIT || 10
    ),

    queueLimit: 0,

    charset: "utf8mb4",

    timezone: "+00:00"
});


async function testConnection() {
    let connection;

    try {
        connection = await pool.getConnection();

        console.log("=================================");
        console.log("MySQL Connection Successful");
        console.log("=================================");
        console.log(
            `Database: ${process.env.DB_NAME || "railway_system"}`
        );
        console.log(
            `Host: ${process.env.DB_HOST || "localhost"}`
        );
        console.log(
            `Port: ${process.env.DB_PORT || 3306}`
        );

        return true;

    } catch (error) {
        console.error("=================================");
        console.error("MySQL Connection Failed");
        console.error("=================================");
        console.error(error.message);

        return false;

    } finally {
        if (connection) {
            connection.release();
        }
    }
}


async function closePool() {
    try {
        await pool.end();

        console.log(
            "MySQL connection pool closed."
        );

    } catch (error) {
        console.error(
            "Error closing MySQL pool:",
            error.message
        );
    }
}


module.exports = {
    pool,
    testConnection,
    closePool
};