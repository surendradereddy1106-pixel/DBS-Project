CREATE DATABASE IF NOT EXISTS railway_system;

USE railway_system;

-- USERS

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(15),
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- TRAINS

CREATE TABLE IF NOT EXISTS trains (
    id INT AUTO_INCREMENT PRIMARY KEY,
    train_number VARCHAR(20) NOT NULL UNIQUE,
    train_name VARCHAR(150) NOT NULL,
    source_station VARCHAR(100) NOT NULL,
    destination_station VARCHAR(100) NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    duration VARCHAR(50)
);


-- PASSENGERS

CREATE TABLE IF NOT EXISTS passengers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    age INT NOT NULL,
    gender ENUM('Male','Female','Other') NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- BOOKINGS

CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pnr VARCHAR(20) NOT NULL UNIQUE,
    passenger_id INT NOT NULL,
    train_id INT NOT NULL,
    journey_date DATE NOT NULL,
    seat_class VARCHAR(10) NOT NULL,
    booking_status VARCHAR(20) DEFAULT 'CONFIRMED',
    booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (passenger_id)
        REFERENCES passengers(id),

    FOREIGN KEY (train_id)
        REFERENCES trains(id)
);


-- TRAINS DATA

INSERT INTO trains
(
    train_number,
    train_name,
    source_station,
    destination_station,
    departure_time,
    arrival_time,
    duration
)
VALUES

(
    '12839',
    'Chennai Mail',
    'HOWRAH',
    'CHENNAI',
    '23:45:00',
    '22:10:00',
    '22h 25m'
),

(
    '12841',
    'Coromandel Express',
    'HOWRAH',
    'CHENNAI',
    '14:50:00',
    '17:00:00',
    '26h 10m'
),

(
    '20703',
    'YPR Vande Bharat',
    'SECUNDERABAD',
    'KURNOOL CITY',
    '05:45:00',
    '08:28:00',
    '02h 43m'
),

(
    '17023',
    'Tungabhadra Express',
    'SECUNDERABAD',
    'KURNOOL CITY',
    '07:55:00',
    '12:30:00',
    '04h 35m'
),

(
    '12648',
    'Kongu SF Express',
    'SECUNDERABAD',
    'KURNOOL CITY',
    '08:30:00',
    '12:48:00',
    '04h 18m'
),

(
    '12708',
    'NZM TPTY SF Express',
    'SECUNDERABAD',
    'KURNOOL CITY',
    '08:55:00',
    '13:08:00',
    '04h 13m'
),

(
    '17021',
    'HYB VSG Express',
    'SECUNDERABAD',
    'KURNOOL CITY',
    '09:55:00',
    '13:53:00',
    '03h 58m'
),

(
    '12760',
    'Charminar Express',
    'HYDERABAD',
    'CHENNAI',
    '18:00:00',
    '08:30:00',
    '14h 30m'
),

(
    '17064',
    'Ajanta Express',
    'HYDERABAD',
    'CHENNAI',
    '18:40:00',
    '09:15:00',
    '14h 35m'
),

(
    '12724',
    'Telangana Express',
    'NEW DELHI',
    'HYDERABAD',
    '16:00:00',
    '14:00:00',
    '22h 00m'
),

(
    '17032',
    'Mumbai Express',
    'MUMBAI',
    'HYDERABAD',
    '21:10:00',
    '13:30:00',
    '16h 20m'
),

(
    '20608',
    'Mysuru Chennai Vande Bharat',
    'BENGALURU',
    'CHENNAI',
    '05:50:00',
    '10:25:00',
    '04h 35m'
),

(
    '12028',
    'Shatabdi Express',
    'BENGALURU',
    'CHENNAI',
    '06:00:00',
    '11:00:00',
    '05h 00m'
),

(
    '12608',
    'Lalbagh Express',
    'BENGALURU',
    'CHENNAI',
    '06:20:00',
    '11:30:00',
    '05h 10m'
)

ON DUPLICATE KEY UPDATE
    train_name = VALUES(train_name),
    source_station = VALUES(source_station),
    destination_station = VALUES(destination_station),
    departure_time = VALUES(departure_time),
    arrival_time = VALUES(arrival_time),
    duration = VALUES(duration);