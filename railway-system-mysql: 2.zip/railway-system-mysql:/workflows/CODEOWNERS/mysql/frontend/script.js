// ========================================
// TRAVEL DATE CALENDAR
// ========================================

function openDatePicker() {
    const datePicker = document.getElementById("travel-date-picker");

    if (!datePicker) return;

    if (typeof datePicker.showPicker === "function") {
        datePicker.showPicker();
    } else {
        datePicker.click();
    }
}

function handleDateChange(dateValue) {
    if (!dateValue) return;

    const date = new Date(dateValue + "T00:00:00");

    if (isNaN(date.getTime())) return;

    const months = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    const weekdays = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
    ];

    const day = String(date.getDate()).padStart(2, "0");
    const month = months[date.getMonth()];
    const year = String(date.getFullYear()).slice(-2);

    document.getElementById("search-travel-date").textContent =
        `${day} ${month} '${year}`;

    document.getElementById("search-travel-day").textContent =
        weekdays[date.getDay()];
}