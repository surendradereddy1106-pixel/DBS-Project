-- =========================================================
-- RAILWAY RESERVATION SYSTEM - DATABASE INITIALIZATION
-- =========================================================

CREATE DATABASE IF NOT EXISTS railway_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;

USE railway_system;


-- =========================================================
-- USERS
-- =========================================================

CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,

    role ENUM(
        'PASSENGER',
        'ADMIN',
        'STAFF'
    ) NOT NULL DEFAULT 'PASSENGER',

    status ENUM(
        'ACTIVE',
        'INACTIVE',
        'BLOCKED'
    ) NOT NULL DEFAULT 'ACTIVE',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_users_email (email),
    INDEX idx_users_phone (phone),
    INDEX idx_users_role (role)
);


-- =========================================================
-- STATIONS
-- =========================================================

CREATE TABLE IF NOT EXISTS stations (
    station_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    station_code VARCHAR(10) NOT NULL UNIQUE,
    station_name VARCHAR(150) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100),
    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_station_code (station_code),
    INDEX idx_station_city (city)
);


-- =========================================================
-- TRAINS
-- =========================================================

CREATE TABLE IF NOT EXISTS trains (
    train_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    train_number VARCHAR(20) NOT NULL UNIQUE,
    train_name VARCHAR(150) NOT NULL,

    train_type ENUM(
        'EXPRESS',
        'SUPERFAST',
        'PASSENGER',
        'LOCAL',
        'SPECIAL'
    ) NOT NULL DEFAULT 'EXPRESS',

    total_coaches INT UNSIGNED NOT NULL DEFAULT 0,

    status ENUM(
        'ACTIVE',
        'INACTIVE',
        'CANCELLED'
    ) NOT NULL DEFAULT 'ACTIVE',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_train_number (train_number),
    INDEX idx_train_status (status)
);


-- =========================================================
-- COACHES
-- =========================================================

CREATE TABLE IF NOT EXISTS coaches (
    coach_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    train_id BIGINT UNSIGNED NOT NULL,
    coach_number VARCHAR(20) NOT NULL,

    coach_type ENUM(
        'SL',
        '3A',
        '2A',
        '1A',
        'CC',
        'EC',
        'GENERAL'
    ) NOT NULL,

    seat_capacity INT UNSIGNED NOT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_coach_train
        FOREIGN KEY (train_id)
        REFERENCES trains(train_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    UNIQUE KEY uk_train_coach (
        train_id,
        coach_number
    ),

    INDEX idx_coach_train (train_id)
);


-- =========================================================
-- ROUTES
-- =========================================================

CREATE TABLE IF NOT EXISTS routes (
    route_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    train_id BIGINT UNSIGNED NOT NULL,

    source_station_id BIGINT UNSIGNED NOT NULL,
    destination_station_id BIGINT UNSIGNED NOT NULL,

    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,

    distance_km DECIMAL(10,2),
    duration_minutes INT UNSIGNED,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_route_train
        FOREIGN KEY (train_id)
        REFERENCES trains(train_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_route_source
        FOREIGN KEY (source_station_id)
        REFERENCES stations(station_id),

    CONSTRAINT fk_route_destination
        FOREIGN KEY (destination_station_id)
        REFERENCES stations(station_id),

    INDEX idx_route_train (train_id),
    INDEX idx_route_source (source_station_id),
    INDEX idx_route_destination (destination_station_id)
);


-- =========================================================
-- JOURNEYS
-- =========================================================

CREATE TABLE IF NOT EXISTS journeys (
    journey_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    train_id BIGINT UNSIGNED NOT NULL,

    journey_date DATE NOT NULL,

    departure_datetime DATETIME NOT NULL,
    arrival_datetime DATETIME NOT NULL,

    status ENUM(
        'SCHEDULED',
        'BOARDING',
        'RUNNING',
        'COMPLETED',
        'CANCELLED',
        'DELAYED'
    ) NOT NULL DEFAULT 'SCHEDULED',

    delay_minutes INT NOT NULL DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_journey_train
        FOREIGN KEY (train_id)
        REFERENCES trains(train_id)
        ON DELETE CASCADE,

    INDEX idx_journey_train (train_id),
    INDEX idx_journey_date (journey_date),
    INDEX idx_journey_status (status)
);


-- =========================================================
-- SEATS
-- =========================================================

CREATE TABLE IF NOT EXISTS seats (
    seat_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    coach_id BIGINT UNSIGNED NOT NULL,

    seat_number VARCHAR(10) NOT NULL,

    seat_type ENUM(
        'LOWER',
        'MIDDLE',
        'UPPER',
        'SIDE_LOWER',
        'SIDE_UPPER',
        'WINDOW',
        'AISLE'
    ),

    status ENUM(
        'AVAILABLE',
        'BLOCKED',
        'MAINTENANCE'
    ) NOT NULL DEFAULT 'AVAILABLE',

    CONSTRAINT fk_seat_coach
        FOREIGN KEY (coach_id)
        REFERENCES coaches(coach_id)
        ON DELETE CASCADE,

    UNIQUE KEY uk_coach_seat (
        coach_id,
        seat_number
    ),

    INDEX idx_seat_coach (coach_id),
    INDEX idx_seat_status (status)
);


-- =========================================================
-- BOOKINGS
-- =========================================================

CREATE TABLE IF NOT EXISTS bookings (
    booking_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    booking_reference VARCHAR(30) NOT NULL UNIQUE,

    user_id BIGINT UNSIGNED NOT NULL,
    journey_id BIGINT UNSIGNED NOT NULL,

    source_station_id BIGINT UNSIGNED NOT NULL,
    destination_station_id BIGINT UNSIGNED NOT NULL,

    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    total_passengers INT UNSIGNED NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,

    status ENUM(
        'PENDING',
        'CONFIRMED',
        'CANCELLED',
        'COMPLETED',
        'WAITING'
    ) NOT NULL DEFAULT 'PENDING',

    payment_status ENUM(
        'PENDING',
        'PAID',
        'FAILED',
        'REFUNDED'
    ) NOT NULL DEFAULT 'PENDING',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_booking_user
        FOREIGN KEY (user_id)
        REFERENCES users(user_id),

    CONSTRAINT fk_booking_journey
        FOREIGN KEY (journey_id)
        REFERENCES journeys(journey_id),

    CONSTRAINT fk_booking_source
        FOREIGN KEY (source_station_id)
        REFERENCES stations(station_id),

    CONSTRAINT fk_booking_destination
        FOREIGN KEY (destination_station_id)
        REFERENCES stations(station_id),

    INDEX idx_booking_reference (booking_reference),
    INDEX idx_booking_user (user_id),
    INDEX idx_booking_journey (journey_id),
    INDEX idx_booking_status (status)
);


-- =========================================================
-- PASSENGERS
-- =========================================================

CREATE TABLE IF NOT EXISTS passengers (
    passenger_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    booking_id BIGINT UNSIGNED NOT NULL,

    full_name VARCHAR(150) NOT NULL,
    age INT UNSIGNED NOT NULL,

    gender ENUM(
        'MALE',
        'FEMALE',
        'OTHER'
    ) NOT NULL,

    id_type VARCHAR(50),
    id_number VARCHAR(100),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_passenger_booking
        FOREIGN KEY (booking_id)
        REFERENCES bookings(booking_id)
        ON DELETE CASCADE,

    INDEX idx_passenger_booking (booking_id)
);


-- =========================================================
-- TICKETS
-- =========================================================

CREATE TABLE IF NOT EXISTS tickets (
    ticket_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    booking_id BIGINT UNSIGNED NOT NULL,
    passenger_id BIGINT UNSIGNED NOT NULL,
    journey_id BIGINT UNSIGNED NOT NULL,

    coach_id BIGINT UNSIGNED,
    seat_id BIGINT UNSIGNED,

    ticket_number VARCHAR(40) NOT NULL UNIQUE,

    fare DECIMAL(10,2) NOT NULL,

    ticket_status ENUM(
        'CONFIRMED',
        'CANCELLED',
        'WAITING'
    ) NOT NULL DEFAULT 'CONFIRMED',

    issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_ticket_booking
        FOREIGN KEY (booking_id)
        REFERENCES bookings(booking_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_ticket_passenger
        FOREIGN KEY (passenger_id)
        REFERENCES passengers(passenger_id),

    CONSTRAINT fk_ticket_journey
        FOREIGN KEY (journey_id)
        REFERENCES journeys(journey_id),

    CONSTRAINT fk_ticket_coach
        FOREIGN KEY (coach_id)
        REFERENCES coaches(coach_id),

    CONSTRAINT fk_ticket_seat
        FOREIGN KEY (seat_id)
        REFERENCES seats(seat_id),

    INDEX idx_ticket_booking (booking_id),
    INDEX idx_ticket_journey (journey_id),
    INDEX idx_ticket_number (ticket_number)
);


-- =========================================================
-- PAYMENTS
-- =========================================================

CREATE TABLE IF NOT EXISTS payments (
    payment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    booking_id BIGINT UNSIGNED NOT NULL,

    transaction_reference VARCHAR(100) NOT NULL UNIQUE,

    amount DECIMAL(12,2) NOT NULL,

    payment_method ENUM(
        'UPI',
        'CARD',
        'NET_BANKING',
        'WALLET',
        'CASH'
    ) NOT NULL,

    payment_status ENUM(
        'PENDING',
        'SUCCESS',
        'FAILED',
        'REFUNDED'
    ) NOT NULL DEFAULT 'PENDING',

    paid_at TIMESTAMP NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_payment_booking
        FOREIGN KEY (booking_id)
        REFERENCES bookings(booking_id)
        ON DELETE CASCADE,

    INDEX idx_payment_booking (booking_id),
    INDEX idx_payment_status (payment_status)
);


-- =========================================================
-- LIVE TRAIN STATUS
-- =========================================================

CREATE TABLE IF NOT EXISTS train_live_status (
    live_status_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    journey_id BIGINT UNSIGNED NOT NULL,

    current_station_id BIGINT UNSIGNED,
    next_station_id BIGINT UNSIGNED,

    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    speed_kmph DECIMAL(8,2),

    delay_minutes INT NOT NULL DEFAULT 0,

    status ENUM(
        'ON_TIME',
        'DELAYED',
        'STOPPED',
        'ARRIVED'
    ) NOT NULL DEFAULT 'ON_TIME',

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_live_journey
        FOREIGN KEY (journey_id)
        REFERENCES journeys(journey_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_live_current_station
        FOREIGN KEY (current_station_id)
        REFERENCES stations(station_id),

    CONSTRAINT fk_live_next_station
        FOREIGN KEY (next_station_id)
        REFERENCES stations(station_id),

    INDEX idx_live_journey (journey_id)
);


-- =========================================================
-- SAMPLE STATIONS
-- =========================================================

INSERT INTO stations
(
    station_code,
    station_name,
    city,
    state
)
VALUES
(
    'HYB',
    'Hyderabad Deccan',
    'Hyderabad',
    'Telangana'
),
(
    'SEC',
    'Secunderabad Junction',
    'Secunderabad',
    'Telangana'
),
(
    'VSKP',
    'Visakhapatnam Junction',
    'Visakhapatnam',
    'Andhra Pradesh'
),
(
    'BZA',
    'Vijayawada Junction',
    'Vijayawada',
    'Andhra Pradesh'
)
ON DUPLICATE KEY UPDATE
    station_name = VALUES(station_name);


-- =========================================================
-- SAMPLE TRAINS
-- =========================================================

INSERT INTO trains
(
    train_number,
    train_name,
    train_type,
    total_coaches
)
VALUES
(
    '12727',
    'Godavari Express',
    'EXPRESS',
    20
),
(
    '12760',
    'Charminar Express',
    'EXPRESS',
    18
)
ON DUPLICATE KEY UPDATE
    train_name = VALUES(train_name);


-- =========================================================
-- ADMIN USER
-- =========================================================

INSERT INTO users
(
    full_name,
    email,
    phone,
    password_hash,
    role
)
VALUES
(
    'System Administrator',
    'admin@railway.com',
    '9999999999',
    '$2b$10$examplehashedpassword',
    'ADMIN'
)
ON DUPLICATE KEY UPDATE
    full_name = VALUES(full_name);


-- =========================================================
-- DATABASE VERIFICATION
-- =========================================================

SELECT
    TABLE_NAME
FROM
    information_schema.TABLES
WHERE
    TABLE_SCHEMA = 'railway_system'
ORDER BY
    TABLE_NAME;